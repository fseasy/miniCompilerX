#ifndef SEMANTIC_ANALYSIS_H_INCLUDED
#define SEMANTIC_ANALYSIS_H_INCLUDED

#define SEMANTIC_STACK_DEPTH 1000
#define TB_NODE_MAX_SIZE 200
#define TB_MAX_NUM 40
struct SemanticNode
{
    /* it is the type at lexical result */
    char lexType[10] ;
    /* it is the value at the lexical result */
    char *lexVal ;
    /* it is the variable's name at symbol table*/
    char tbName[20] ;
    /* if the addr of the variable */
    void * tbAddr ;
} ;
struct SemanticStack
{
    struct SemanticNode data[SEMANTIC_STACK_DEPTH] ;
    char valStringBuf[SEMANTIC_STACK_DEPTH*10] ; //for the lexVal
    char *bufPos ;
    int top ;
} semanticS ;
/* symbol table*/
struct tbNode
{
    char name[20] ;
    char type[16] ;
    void * addr ;
} ;
struct symbolTb
{
    struct symbolTb * previous ;
    int width ;
    int counter ;
    struct tbNode * data[TB_NODE_MAX_SIZE] ;
} ;
/* offset stack and tbptr stack */
struct OffsetStack
{
    void * data[TB_MAX_NUM] ;
    int top ;
} offsetS ;
struct TbptrStack
{
    struct symbolTb  * data[TB_MAX_NUM] ;
    int top ;
} tbptrS ;
/* tmp variable */


void initSemanticS() ;
int semanticAct(int pdtIndex) ;
void shiftSemanticAct(char lecType[] , char lexVal[]) ;
const char * decideType(int pos1 , int pos2) ;
/*tb operator */
struct symbolTb * mkTb(struct symbolTb * previous) ;
/* return the addr */
void * enterTb(struct symbolTb * tb , char * name ,char * type , void * offset) ;
int getSize(char * type) ;
/* return the addr of the tbNode  or null */
struct tbNode * lookupTb(struct symbolTb * tb , char * name) ;

/* offset stack , tbptr stack op */
void initOffsetS() ;
void initTbptrS() ;

/* newtmp */
char * getTmpName() ;
#endif // SEMANTIC_ANALYSIS,H_H_INCLUDED
