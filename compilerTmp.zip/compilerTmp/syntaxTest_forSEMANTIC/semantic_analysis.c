
#include "semantic_analysis.h"
#include "analysis_table.h"
#include <stdio.h>

#define ACT_S_S	0
#define ACT_S_INT_ID_SEMIC_S	1
#define ACT_S_ID_ASSIGN_E_SEMIC	2
#define ACT_S	3
#define ACT_E_T_ADD_E	4
#define ACT_E_T_SUB_E	5
#define ACT_E_T	6
#define ACT_T_F_MUL_T	7
#define ACT_T_F_DIV_T	8
#define ACT_T_F	9
#define ACT_F_ID	10
#define ACT_F_DIGIT	11
#define ACT_DIGIT_INT_C	12
#define ACT_DIGIT_REAL_C	13
#define ACT_ACT1 14

int tmpID = 0 ;
void genCode(char * str)
{
    printf(str) ;
}
void initSemanticS()
{
    semanticS.top = 0 ;
    semanticS.bufPos = (char *)semanticS.valStringBuf ;
}
void shiftSemanticAct(char lexType[] , char lexVal[])
{
    strcpy(semanticS.data[semanticS.top].lexType , lexType ) ;
    strcpy(semanticS.bufPos , lexVal) ;
    semanticS.data[semanticS.top].lexVal = semanticS.bufPos ;
    semanticS.bufPos += 1 + strlen(semanticS.bufPos) ; //yeah , should add 1 more
    semanticS.top ++ ;
}
char * getNodeType(int pos)
{
    if((semanticS.data[pos].lexType,"ID") == 0)
    {
        struct tbNode * tmp = lookupTb(tbptrS.data[tbptrS.top -1] , semanticS.data[pos].lexVal) ;
        return tmp->type ;
    }
    else
    {
        return semanticS.data[pos].lexType ;
    }
}
const char * decideType(int pos1 , int pos2)
{
    char *type1 , *type2 ;
    type1 = getNodeType(pos1) ;
    type2 = getNodeType(pos2) ;
    //is all legal?
    if(strcmp(type1,"BOOL") == 0 || strcmp(type1,"CHAR") == 0
        || strcmp(type2,"BOOL") == 0 || strcmp(type2,"CHAR") == 0)
        {
            printf("illegal operation between  %s and %s ",type1 , type2) ;
            return NULL ;
        }
    if(strcmp(type1 , "DOUBLE") == 0 || strcmp(type2,"DOUBLE") == 0)
    {
        return "DOUBLE" ;
    }
    else
    {
        return "INT" ;
    }
}
struct symbolTb * mkTb(struct symbolTb * previous)
{
    struct symbolTb * newTb = (struct symbolTb *)malloc(sizeof(struct symbolTb)) ;
    newTb->counter = 0 ;
    newTb->previous = previous ;
    newTb->width = 0 ;
    return newTb ;
}

/*  enter to the table ,including not only the variable but also the new table
    if type == "TABLE" , it is to add a table link !
    return the addr of the new new variable
    or the addr of the new table */
void * enterTb(struct symbolTb * tb , char * name ,char * type , void * offset)
{
    /*first ensure has the same name ? */
    int k ;
    for(k = 0 ; k < tb->counter ; k++)
    {
        if(strcmp(tb->data[k]->name , name) == 0)
        {
            return NULL ;
        }
    }
    tb->data[tb->counter] = (struct tbNode *) malloc(sizeof(struct tbNode)) ;
    strcpy(tb->data[tb->counter]->name , name ) ;
    /* if the type is TABLE , we should create a new table and return the table's pointer */
    strcpy(tb->data[tb->counter]->type , type) ;
    if(strcmp(type,"TABLE") == 0)
    {
        /*enter a table , don't change the width */
        tb->data[tb->counter]->addr = (void *)mkTb(tb) ;
    }
    else
    {
        tb->data[tb->counter]->addr = offset ;
    }
    tb->counter++ ;
    return tb->data[tb->counter -1]->addr ;
}
/* return the addr or null */
struct tbNode * lookupTb(struct symbolTb * tb , char * name)
{
    int k ;
    for(k = 0 ; k < tb->counter ; k++)
    {
        if(strcmp(tb->data[k]->name,name) == 0)
        {
            return tb->data[k] ;
        }
    }
    /* find previous */
    struct symbolTb * pos = tb->previous ;
    struct symbolTb * cur = tb ;
    while(pos != NULL)
    {

        for(k = 0 ; pos->data[k]->addr != cur ; k++)
        {
            if(strcmp(pos->data[k]->name , name) == 0)
            {
                return pos->data[k] ;
            }
        }
        cur = pos ;
        pos = cur->previous ;
    }
    printf("no such variable named '%s' \n",name) ;
    return NULL ;
}

/* offset stack , tbptr stack op */
void initOffsetS()
{
    offsetS.top = 0 ;
}
void initTbptrS()
{
    tbptrS.top = 0 ;
}
char * getTmpName()
{
    char * tmpName =  (char *)malloc(sizeof(char) * 10) ;
    sprintf(tmpName,"tmp_%d",tmpID) ;
    tmpID++ ;
    return tmpName ;
}
int semanticAct(int pdtIndex)
{
    char * name ;
    char * type ;
    int size ;
    void * addr ;
    char outputStr[100] ;
    struct symbolTb * curTb = tbptrS.data[tbptrS.top -1] ;
	switch(pdtIndex)
	{
		case ACT_S_S :
		{

			break ;
		}
		case ACT_S_INT_ID_SEMIC_S :
		{
            semanticS.top -= 4 ;
			break ;
		}
		case ACT_S_ID_ASSIGN_E_SEMIC :
		{
		    /* there ID has not have the tbName and tbAddr attribute */
		    struct tbNode * nodeTmp = lookupTb(curTb,semanticS.data[semanticS.top -4].lexVal) ;
		    if(nodeTmp == NULL) return FALSE_ANA ;
		    strcpy(semanticS.data[semanticS.top -4].tbName,nodeTmp->name) ;
		    semanticS.data[semanticS.top -4].tbAddr = nodeTmp->addr ;
            sprintf(outputStr,"%s = %s [%p = % p]\n" ,
                    semanticS.data[semanticS.top -4].tbName , semanticS.data[semanticS.top -2].tbName ,
                    semanticS.data[semanticS.top -4].tbAddr , semanticS.data[semanticS.top -2].tbAddr) ;
			genCode(outputStr) ;
			semanticS.top -= 4 ;
			break ;
		}
		case ACT_S :
		{
            semanticS.top ++ ;
			break ;
		}
		case ACT_E_T_ADD_E :
		{
            name = getTmpName() ;
            /* we should decide the type */
            type = decideType(semanticS.top - 1 , semanticS.top -3) ;
            addr = enterTb(curTb , name ,type , offsetS.data[offsetS.top -1]) ;
            size = getSize(type) ;
            offsetS.data[offsetS.top -1]+= size ;
            sprintf(outputStr , "%s = %s + %s [%p = %p + %p ]\n",name , semanticS.data[semanticS.top -1].tbName , semanticS.data[semanticS.top -3].tbName ,
                                                               addr , semanticS.data[semanticS.top -1].tbAddr , semanticS.data[semanticS.top -3].tbAddr) ;
			genCode(outputStr) ;
			/* !! pop stack */
			semanticS.top -= 2 ;
			struct SemanticNode * nodeTmp = &(semanticS.data[semanticS.top -1]) ;
			strcpy(nodeTmp->lexType,"ID") ;
			strcpy(nodeTmp->lexVal,name) ;
			strcpy(nodeTmp->tbName,name) ;
			nodeTmp->tbAddr = addr ;
			free(name) ;
			break ;
		}
		case ACT_E_T_SUB_E :
		{
            name = getTmpName() ;
            /* we should decide the type */
            type = decideType(semanticS.top - 1 , semanticS.top -3) ;
            addr = enterTb(curTb , name ,type , offsetS.data[offsetS.top -1]) ;
            size = getSize(type) ;
            offsetS.data[offsetS.top -1]+= size ;
            sprintf(outputStr , "%s = %s - %s [%p = %p - %p ]\n",name , semanticS.data[semanticS.top -1].tbName , semanticS.data[semanticS.top -3].tbName ,
                                                               addr , semanticS.data[semanticS.top -1].tbAddr , semanticS.data[semanticS.top -3].tbAddr) ;
			genCode(outputStr) ;
			/* !! pop stack */
			semanticS.top -= 2 ;
			struct SemanticNode * nodeTmp = &semanticS.data[semanticS.top -1] ;
			strcpy(nodeTmp->lexType,"ID") ;
			strcpy(nodeTmp->lexVal,name) ;
			strcpy(nodeTmp->tbName,name) ;
			nodeTmp->tbAddr = addr ;
			free(name) ;
			break ;
		}
		case ACT_E_T :
		{

			break ;
		}
		case ACT_T_F_MUL_T :
		{
		    name = getTmpName() ;
            /* we should decide the type */
            type = decideType(semanticS.top - 1 , semanticS.top -3) ;
            addr = enterTb(curTb , name ,type , offsetS.data[offsetS.top -1]) ;
            size = getSize(type) ;
            offsetS.data[offsetS.top -1]+= size ;
            sprintf(outputStr , "%s = %s * %s [%p = %p * %p ]\n",name , semanticS.data[semanticS.top -1].tbName , semanticS.data[semanticS.top -3].tbName ,
                                                               addr , semanticS.data[semanticS.top -1].tbAddr , semanticS.data[semanticS.top -3].tbAddr) ;
			genCode(outputStr) ;
			/* !! pop stack */
			semanticS.top -= 2 ;
			struct SemanticNode * nodeTmp = &semanticS.data[semanticS.top -1] ;
			strcpy(nodeTmp->lexType,"ID") ;
			strcpy(nodeTmp->lexVal,name) ;
			strcpy(nodeTmp->tbName,name) ;
			nodeTmp->tbAddr = addr ;
			free(name) ;

			break ;
		}
		case ACT_T_F_DIV_T :
		{
            name = getTmpName() ;
            /* we should decide the type */
            type = decideType(semanticS.top - 1 , semanticS.top -3) ;
            addr = enterTb(curTb , name ,type , offsetS.data[offsetS.top -1]) ;
            size = getSize(type) ;
            offsetS.data[offsetS.top -1]+= size ;
            sprintf(outputStr , "%s = %s / %s [%p = %p / %p ]\n",name , semanticS.data[semanticS.top -1].tbName , semanticS.data[semanticS.top -3].tbName ,
                                                               addr , semanticS.data[semanticS.top -1].tbAddr , semanticS.data[semanticS.top -3].tbAddr) ;
			genCode(outputStr) ;
			/* !! pop stack */
			semanticS.top -= 2 ;
			struct SemanticNode * nodeTmp = &semanticS.data[semanticS.top -1] ;
			strcpy(nodeTmp->lexType,"ID") ;
			strcpy(nodeTmp->lexVal,name) ;
			strcpy(nodeTmp->tbName,name) ;
			nodeTmp->tbAddr = addr ;
			free(name) ;
			break ;
		}
		case ACT_T_F :
		{

			break ;
		}
		case ACT_F_ID :
		{
            name = semanticS.data[semanticS.top -1].lexVal ;
            struct tbNode * nodeTmp = lookupTb(curTb,name) ;
            if(nodeTmp == NULL) return FALSE_ANA ;
            type = nodeTmp->type ;
            addr = nodeTmp->addr ;
            strcpy(semanticS.data[semanticS.top -1].tbName , name) ;
            semanticS.data[semanticS.top -1].tbAddr = addr ;
			break ;
		}
		case ACT_F_DIGIT :
		{

			break ;
		}
		case ACT_DIGIT_INT_C :
		{
            name = getTmpName() ;
            type = "INT" ;
            addr = enterTb(curTb , name , type ,offsetS.data[offsetS.top -1]) ;
            size = getSize(type) ;
            offsetS.data[offsetS.top -1]+=size ;
            sprintf(outputStr,"%s = %s [%p = %s]\n",name , semanticS.data[semanticS.top -1].lexVal ,
                                                    addr , semanticS.data[semanticS.top -1].lexVal) ;
			genCode(outputStr) ;
			strcpy(semanticS.data[semanticS.top -1].tbName,name) ;
			semanticS.data[semanticS.top -1].tbAddr = addr ;
			free(name) ;
			break ;
		}
		case ACT_DIGIT_REAL_C :
		{
            name = getTmpName() ;
            type = "DOUBLE" ;
            addr = enterTb(curTb , name , type ,offsetS.data[offsetS.top -1]) ;
            size = getSize(type) ;
            offsetS.data[offsetS.top -1]+=size ;
            sprintf(outputStr , "%s = %s [%p = %s]\n" , name , semanticS.data[semanticS.top -1].lexVal ,
                                                        addr , semanticS.data[semanticS.top -1].lexVal) ;
            genCode(outputStr) ;
            strcpy(semanticS.data[semanticS.top -1].tbName , name) ;
            semanticS.data[semanticS.top - 1].tbAddr = addr ;
            free(name) ;
			break ;
		}
		case ACT_ACT1 :
        {
            //enter the ID to the table
            name = semanticS.data[semanticS.top -2].lexVal ;
            type = (char *)semanticS.data[semanticS.top -3].lexType ;
            addr = enterTb(tbptrS.data[tbptrS.top-1],name,type,offsetS.data[offsetS.top -1]) ;
            size = getSize(type) ;
            offsetS.data[offsetS.top -1] += size ;
            break ;
        }
		default:
            printf("NONO") ;
			break ;
	}
	return TRUE_ANA ;
}
int getSize(char * type)
{
    if(strcmp(type,"INT") == 0 )
    {
        return 4 ;
    }
    else if(strcmp(type,"CHAR") == 0 || strcmp(type , "BOOL") == 0)
    {
        return 1 ;
    }
    else if(strcmp(type , "DOUBLE") == 0)
    {
        return 8 ;
    }
    else
    {
        return 0 ;
    }
}
