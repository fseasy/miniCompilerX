#include <stdio.h>
#include <stdlib.h>

#include "hash.h"
#include "analysis_table.h"
#include "semantic_analysis.h"

#define OU
#define STACK_DEPTH 1000
int getLineInfo(FILE * fp , char * words ,  char * valOrAddr)
{
    int ret ;
    char tmp[30] = "" ;
    ret = fscanf(fp,"%s",words) ;
    if(ret == EOF)
    {
        return EOF ;
    }
    /* read , */
    ret = fscanf(fp,"%s",tmp) ;
    if(ret == EOF)
    {
        printf("Input File not corrected!\n") ;
        return EOF ;
    }
    ret = fscanf(fp,"%s",valOrAddr) ;
    if(ret == EOF)
    {
        printf("Input File not corrected!\n") ;
        return EOF ;
    }
    if(strcmp(valOrAddr,";") == 0)
    {
        /* no this parameter */
        valOrAddr[0] = '\0' ;
        return 1 ;
    }
    else
    {
        /* read the ';' */
        fscanf(fp,"%s",tmp) ;
        return 1 ;
    }
}
int syntaxAnalysis(char * fileName)
{
    FILE * sourceFile = fopen(fileName,"r") ;
    if(!sourceFile)
    {
        printf("can not open file '%s'\n",fileName) ;
        return -1 ;
    }
    char  words[30] = "" ;
    char valOrAddr[500] = "" ;
    struct Stack
    {
        int data[STACK_DEPTH] ;
        int top ;
    } ; //EA stack
    struct Stack stateS ;
    struct Stack symbolS ;
    /* -----------init-------------- */
    stateS.top = 0 ;
    symbolS.top = 0 ;
    stateS.data[stateS.top++] = 0 ;
    symbolS.data[symbolS.top++] = transName("#") ;
        /** init semanticS */
    initSemanticS() ;
        /* make a global sybolTb */
    struct symbolTb * globalTb = mkTb(NULL) ;
        /* init the offset stack , tbptr stack */
    initTbptrS() ;
    initOffsetS() ;
    offsetS.data[offsetS.top++] = 0 ;
    tbptrS.data[tbptrS.top++] = globalTb ;
    //-------------------
    //fscanf(sourceFile,"%s",words) ;
    getLineInfo(sourceFile,words,valOrAddr) ;
    while(1)
    {
        #ifdef OUTPUT_ANALYSIS_STACK
        int j = 0 ;
        for( ; j < stateS.top ; j++)
        {
            printf("%d,",stateS.data[j]) ;
        }
        printf("\n") ;
        for( j = 0 ; j < stateS.top ; j++)
        {
            printf("%s,",getName(symbolS.data[j]) ) ;
        }
        printf("\n") ;
        #endif
        #ifdef OUTPUT_READLINE
        printf("--words:%s\n--valoraddr:%s\n",words,valOrAddr) ;
        #endif
        #ifdef OUTPUT_SEMANTIC_STACK
        int dk = 0 ;
        printf("--semantic_stack--\n") ;
        for( ; dk < semanticS.top ; dk++)
        {
            printf("[%s,%s,%s] | ",semanticS.data[dk].lexType,semanticS.data[dk].lexVal,semanticS.data[dk].tbName) ;
        }
        printf("\n") ;
        #endif
        int symbol = transName(words) ;
        if(symbol != EMPTY)
        {
                // find ACTION
                #ifdef OUTPUT_STATUS
                int cState = stateS.data[stateS.top -1 ] ;
                printf("current state=%d,symbol=%d,%s",cState,symbol,getName(symbol)) ;
                #endif
                int val = analysisTable.table[stateS.data[stateS.top -1 ]][symbol] ;
                if(val == ACC )
                {
                    printf("ACC\n") ;
                    return 0 ;
                }
                else if(val == ERROR)
                {
                    printf("something error\n") ;
                    return -1 ;
                }
                else if(val >= 0 )
                {
                    /* shift */
                    symbolS.data[symbolS.top++] = symbol ;
                    stateS.data[stateS.top++] = val ;
                    shiftSemanticAct(words,valOrAddr) ;
                    #ifdef SYNTAX
                    printf("shift %s\n",getName(symbol)) ;
                    #endif
                    /* read next */
                    //if(fscanf(sourceFile,"%s",words) == EOF)
                    if(getLineInfo(sourceFile,words,valOrAddr) == EOF)
                    {
                        strcpy(words,"#") ;
                    }
                }
                else if(val < 0)
                {
                    /* reduce */
                    val = - val ;
                    /*print */
                    char * proS = restoreP(val) ;
                    #ifdef SYNTAX
                    printf("%s\n",proS) ;
                    #endif
                   if(semanticAct(val) == FALSE_ANA) return FALSE_ANA ;
                    //free(proS) ;
                    /* stack pop */
                    int len = productions.data[val].len ;
                    stateS.top = stateS.top - len ;
                    symbolS.top  = symbolS.top - len ;
                    /* stack push */
                        /* we should get the production left */
                    int pLeft = productions.data[val].pLeft ;
                    symbolS.data[symbolS.top++] = pLeft ;
                    /* look up goto table*/
                    int gotoState = analysisTable.table[stateS.data[stateS.top -1]][pLeft] ;
                    if(gotoState == ERROR)
                    {
                        printf("GOTO table occured error") ;
                        return -1 ;
                    }
                    stateS.data[stateS.top++] = gotoState ;
                }
        }
        else
        {
            printf("not supported symbol !\n") ;
            return -1 ;
        }
    }
    return 0 ;
}
int main(int argc , char * argv[])
{
    initAnalysisTable() ;
    if(argc == 1)
    {
        syntaxAnalysis("test.out");
    }
    else
    {
        if(strcmp(argv[1],"genfile") == 0)
        {
            genfile() ;
            printf("ok") ;
        }
        else
        {
            printf("%s",argv[1]) ;
        }
    }

    return 0;
}
