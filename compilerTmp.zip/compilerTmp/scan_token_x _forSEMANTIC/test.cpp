#include <iostream>
using namespace std;
struct type{
    float f;
    char c;
    int i;
};

int main() {
    char a = 1;
    cout<<sizeof(a+1)<<endl;

    cout<<sizeof(type)<<endl;
}
