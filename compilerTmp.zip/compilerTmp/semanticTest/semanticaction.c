#define ACT_S_S	0
void semanticAct(int pdtIndex)
{
	switch(pdtIndex)
	{
		case ACT_S_S :
		{

			break ; 
		}
		default:
			break ;
	}
}
