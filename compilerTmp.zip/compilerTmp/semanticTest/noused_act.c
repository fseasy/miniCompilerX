int semanticAct_xx(int pdtIndex)
{
    char * name ;
    char * type ;
    int size ;
    void * addr ;
    char outputStr[100] ;
    struct symbolTb * curTb = tbptrS.data[tbptrS.top -1] ;
	switch(pdtIndex)
	{
		case ACT_S_S :
		{

			break ;
		}
		case ACT_S_INT_ID_SEMIC_S :
		{
            semanticS.top -= 4 ;
			break ;
		}
		case ACT_S_ID_ASSIGN_E_SEMIC :
		{
		    /* there ID has not have the tbName and tbAddr attribute */
		    struct tbNode * nodeTmp = lookupTb(curTb,semanticS.data[semanticS.top -4].lexVal) ;
		    if(nodeTmp == NULL) return FALSE_ANA ;
		    strcpy(semanticS.data[semanticS.top -4].tbName,nodeTmp->name) ;
		    semanticS.data[semanticS.top -4].tbAddr = nodeTmp->addr ;
            sprintf(outputStr,"%s = %s [%p = % p]\n" ,
                    semanticS.data[semanticS.top -4].tbName , semanticS.data[semanticS.top -2].tbName ,
                    semanticS.data[semanticS.top -4].tbAddr , semanticS.data[semanticS.top -2].tbAddr) ;
			genCode(outputStr) ;
			semanticS.top -= 4 ;
			break ;
		}
		case ACT_S :
		{
            semanticS.top ++ ;
			break ;
		}
		case ACT_E_T_ADD_E :
		{
            name = getTmpName() ;
            /* we should decide the type */
            type = decideType(semanticS.top - 1 , semanticS.top -3) ;
            addr = enterTb(curTb , name ,type , offsetS.data[offsetS.top -1]) ;
            size = getSize(type) ;
            offsetS.data[offsetS.top -1]+= size ;
            sprintf(outputStr , "%s = %s + %s [%p = %p + %p ]\n",name , semanticS.data[semanticS.top -1].tbName , semanticS.data[semanticS.top -3].tbName ,
                                                               addr , semanticS.data[semanticS.top -1].tbAddr , semanticS.data[semanticS.top -3].tbAddr) ;
			genCode(outputStr) ;
			/* !! pop stack */
			semanticS.top -= 2 ;
			struct SemanticNode * nodeTmp = &(semanticS.data[semanticS.top -1]) ;
			strcpy(nodeTmp->lexType,"ID") ;
			strcpy(nodeTmp->lexVal,name) ;
			strcpy(nodeTmp->tbName,name) ;
			nodeTmp->tbAddr = addr ;
			free(name) ;
			break ;
		}
		case ACT_E_T_SUB_E :
		{
            name = getTmpName() ;
            /* we should decide the type */
            type = decideType(semanticS.top - 1 , semanticS.top -3) ;
            addr = enterTb(curTb , name ,type , offsetS.data[offsetS.top -1]) ;
            size = getSize(type) ;
            offsetS.data[offsetS.top -1]+= size ;
            sprintf(outputStr , "%s = %s - %s [%p = %p - %p ]\n",name , semanticS.data[semanticS.top -1].tbName , semanticS.data[semanticS.top -3].tbName ,
                                                               addr , semanticS.data[semanticS.top -1].tbAddr , semanticS.data[semanticS.top -3].tbAddr) ;
			genCode(outputStr) ;
			/* !! pop stack */
			semanticS.top -= 2 ;
			struct SemanticNode * nodeTmp = &semanticS.data[semanticS.top -1] ;
			strcpy(nodeTmp->lexType,"ID") ;
			strcpy(nodeTmp->lexVal,name) ;
			strcpy(nodeTmp->tbName,name) ;
			nodeTmp->tbAddr = addr ;
			free(name) ;
			break ;
		}
		case ACT_E_T :
		{

			break ;
		}
		case ACT_T_F_MUL_T :
		{
		    name = getTmpName() ;
            /* we should decide the type */
            type = decideType(semanticS.top - 1 , semanticS.top -3) ;
            addr = enterTb(curTb , name ,type , offsetS.data[offsetS.top -1]) ;
            size = getSize(type) ;
            offsetS.data[offsetS.top -1]+= size ;
            sprintf(outputStr , "%s = %s * %s [%p = %p * %p ]\n",name , semanticS.data[semanticS.top -1].tbName , semanticS.data[semanticS.top -3].tbName ,
                                                               addr , semanticS.data[semanticS.top -1].tbAddr , semanticS.data[semanticS.top -3].tbAddr) ;
			genCode(outputStr) ;
			/* !! pop stack */
			semanticS.top -= 2 ;
			struct SemanticNode * nodeTmp = &semanticS.data[semanticS.top -1] ;
			strcpy(nodeTmp->lexType,"ID") ;
			strcpy(nodeTmp->lexVal,name) ;
			strcpy(nodeTmp->tbName,name) ;
			nodeTmp->tbAddr = addr ;
			free(name) ;

			break ;
		}
		case ACT_T_F_DIV_T :
		{
            name = getTmpName() ;
            /* we should decide the type */
            type = decideType(semanticS.top - 1 , semanticS.top -3) ;
            addr = enterTb(curTb , name ,type , offsetS.data[offsetS.top -1]) ;
            size = getSize(type) ;
            offsetS.data[offsetS.top -1]+= size ;
            sprintf(outputStr , "%s = %s / %s [%p = %p / %p ]\n",name , semanticS.data[semanticS.top -1].tbName , semanticS.data[semanticS.top -3].tbName ,
                                                               addr , semanticS.data[semanticS.top -1].tbAddr , semanticS.data[semanticS.top -3].tbAddr) ;
			genCode(outputStr) ;
			/* !! pop stack */
			semanticS.top -= 2 ;
			struct SemanticNode * nodeTmp = &semanticS.data[semanticS.top -1] ;
			strcpy(nodeTmp->lexType,"ID") ;
			strcpy(nodeTmp->lexVal,name) ;
			strcpy(nodeTmp->tbName,name) ;
			nodeTmp->tbAddr = addr ;
			free(name) ;
			break ;
		}
		case ACT_T_F :
		{

			break ;
		}
		case ACT_F_ID :
		{
            name = semanticS.data[semanticS.top -1].lexVal ;
            struct tbNode * nodeTmp = lookupTb(curTb,name) ;
            if(nodeTmp == NULL) return FALSE_ANA ;
            type = nodeTmp->type ;
            addr = nodeTmp->addr ;
            strcpy(semanticS.data[semanticS.top -1].tbName , name) ;
            semanticS.data[semanticS.top -1].tbAddr = addr ;
			break ;
		}
		case ACT_F_DIGIT :
		{

			break ;
		}
		case ACT_DIGIT_INT_C :
		{
            name = getTmpName() ;
            type = "INT" ;
            addr = enterTb(curTb , name , type ,offsetS.data[offsetS.top -1]) ;
            size = getSize(type) ;
            offsetS.data[offsetS.top -1]+=size ;
            sprintf(outputStr,"%s = %s [%p = %s]\n",name , semanticS.data[semanticS.top -1].lexVal ,
                                                    addr , semanticS.data[semanticS.top -1].lexVal) ;
			genCode(outputStr) ;
			strcpy(semanticS.data[semanticS.top -1].tbName,name) ;
			semanticS.data[semanticS.top -1].tbAddr = addr ;
			free(name) ;
			break ;
		}
		case ACT_DIGIT_REAL_C :
		{
            name = getTmpName() ;
            type = "DOUBLE" ;
            addr = enterTb(curTb , name , type ,offsetS.data[offsetS.top -1]) ;
            size = getSize(type) ;
            offsetS.data[offsetS.top -1]+=size ;
            sprintf(outputStr , "%s = %s [%p = %s]\n" , name , semanticS.data[semanticS.top -1].lexVal ,
                                                        addr , semanticS.data[semanticS.top -1].lexVal) ;
            genCode(outputStr) ;
            strcpy(semanticS.data[semanticS.top -1].tbName , name) ;
            semanticS.data[semanticS.top - 1].tbAddr = addr ;
            free(name) ;
			break ;
		}
		case ACT_ACT1 :
        {
            //enter the ID to the table
            name = semanticS.data[semanticS.top -2].lexVal ;
            type = (char *)semanticS.data[semanticS.top -3].lexType ;
            addr = enterTb(tbptrS.data[tbptrS.top-1],name,type,offsetS.data[offsetS.top -1]) ;
            size = getSize(type) ;
            offsetS.data[offsetS.top -1] += size ;
            break ;
        }
		default:
            printf("NONO") ;
			break ;
	}
	return TRUE_ANA ;
}
