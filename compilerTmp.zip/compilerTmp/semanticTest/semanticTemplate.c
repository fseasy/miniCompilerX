#define ACT_P_X	0
#define ACT_X_funDefine_X	1
#define ACT_X_mainFun	2
#define ACT_funDefine_funHead_funBody	3
#define ACT_funHead_returnType_ID_ACT_1_LR_BRAC_formalParam_RR_BRAC	4
#define ACT_funBody_LB_BRAC_funDomain_RB_BRAC	5
#define ACT_funDomain_declaration_funDomain	6
#define ACT_funDomain_assignment_funDomain	7
#define ACT_funDomain_condition_funDomain	8
#define ACT_funDomain_loop_funDomain	9
#define ACT_funDomain_io_funDomain	10
#define ACT_funDomain_funApply_funDomain	11
#define ACT_funDomain_jumpWord_funDomain	12
#define ACT_funDomain_SEMIC_funDomain	13
#define ACT_funDomain	14
#define ACT_returnType_INT	15
#define ACT_returnType_DOUBLE	16
#define ACT_returnType_CHAR	17
#define ACT_returnType_BOOL	18
#define ACT_returnType_VOID	19
#define ACT_formalParam_paramList	20
#define ACT_formalParam	21
#define ACT_paramList_type_ID_COMMA_paramList	22
#define ACT_paramList_type_ID	23
#define ACT_type_INT	24
#define ACT_type_DOUBLE	25
#define ACT_type_BOOL	26
#define ACT_type_CHAR	27
#define ACT_declaration_type_idList_SEMIC	28
#define ACT_idList_ID_COMMA_idList	29
#define ACT_idList_ID	30
#define ACT_assignment_ID_ASSIGN_EXP_SEMIC	31
#define ACT_assignment_ID_ASSIGN_funApply	32
#define ACT_assignment_singleOP_SEMIC	33
#define ACT_EXP_E_AND_EXP	34
#define ACT_EXP_E_OR_EXP	35
#define ACT_EXP_E	36
#define ACT_E_T_ADD_E	37
#define ACT_E_T_SUB_E	38
#define ACT_E_T	39
#define ACT_T_F_MUL_OR_INDIR_T	40
#define ACT_T_F_DIV_T	41
#define ACT_T_F	42
#define ACT_F_G_relOP_G	43
#define ACT_F_G	44
#define ACT_G_LR_BRAC_EXP_RR_BRAC	45
#define ACT_G_ID	46
#define ACT_G_TRUE	47
#define ACT_G_FALSE	48
#define ACT_G_DIGIT	49
#define ACT_G_CHAR_C	50
#define ACT_DIGIT_INT_C	51
#define ACT_DIGIT_REAL_C	52
#define ACT_relOP_EQ	53
#define ACT_relOP_NEQ	54
#define ACT_relOP_GE	55
#define ACT_relOP_GT	56
#define ACT_relOP_LE	57
#define ACT_relOP_LT	58
#define ACT_funApply_ID_LR_BRAC_acturalParam_RR_BRAC_SEMIC	59
#define ACT_acturalParam_idList	60
#define ACT_acturalParam	61
#define ACT_singleOP_INC_ID	62
#define ACT_singleOP_ID_INC	63
#define ACT_singleOP_DEC_ID	64
#define ACT_singleOP_ID_DEC	65
#define ACT_condition_IF_LR_BRAC_EXP_ACT_2_RR_BRAC_funBody	66
#define ACT_condition_IF_LR_BRAC_EXP_ACT_2_RR_BRAC_funBody_ACT_3_ELSE_funBody	67
#define ACT_loop_FOR_LR_BRAC_forAssignPart_ACT_4_SEMIC_forBoolPart_ACT_5_SEMIC_forAssignPart_ACT_6_RR_BRAC_funBody	68
#define ACT_forAssignPart_forAssignList	69
#define ACT_forAssignPart	70
#define ACT_forAssignList_forAssignment_COMMA_forAssignList	71
#define ACT_forAssignList_forAssignment	72
#define ACT_forAssignment_ID_ASSIGN_EXP	73
#define ACT_forAssignment_singleOP	74
#define ACT_forBoolPart_EXP	75
#define ACT_forBoolPart	76
#define ACT_jumpWord_returnWord	77
#define ACT_jumpWord_CONTINUE_SEMIC	78
#define ACT_jumpWord_BREAK_SEMIC	79
#define ACT_returnWord_RETURN_returnVal_SEMIC	80
#define ACT_returnVal_EXP	81
#define ACT_returnVal	82
#define ACT_io_PRINTF_LR_BRAC_printContent_RR_BRAC_SEMIC	83
#define ACT_io_SCANF_LR_BRAC_STRING_C_COMMA_REFERENCE_ID_RR_BRAC_SEMIC	84
#define ACT_printContent_STRING_C	85
#define ACT_printContent_STRING_C_COMMA_ID	86
#define ACT_mainFun_INT_MAIN_ACT_1_LR_BRAC_formalParam_RR_BRAC_funBody	87
#define ACT_ACT_1	88
#define ACT_ACT_2	89
#define ACT_ACT_3	90
#define ACT_ACT_4	91
#define ACT_ACT_5	92
#define ACT_ACT_6	93
int semanticAct(int pdtIndex)
{
	switch(pdtIndex)
	{
		case ACT_P_X :
		{

			break ; 
		}
		case ACT_X_funDefine_X :
		{

			break ; 
		}
		case ACT_X_mainFun :
		{

			break ; 
		}
		case ACT_funDefine_funHead_funBody :
		{

			break ; 
		}
		case ACT_funHead_returnType_ID_ACT_1_LR_BRAC_formalParam_RR_BRAC :
		{

			break ; 
		}
		case ACT_funBody_LB_BRAC_funDomain_RB_BRAC :
		{

			break ; 
		}
		case ACT_funDomain_declaration_funDomain :
		{

			break ; 
		}
		case ACT_funDomain_assignment_funDomain :
		{

			break ; 
		}
		case ACT_funDomain_condition_funDomain :
		{

			break ; 
		}
		case ACT_funDomain_loop_funDomain :
		{

			break ; 
		}
		case ACT_funDomain_io_funDomain :
		{

			break ; 
		}
		case ACT_funDomain_funApply_funDomain :
		{

			break ; 
		}
		case ACT_funDomain_jumpWord_funDomain :
		{

			break ; 
		}
		case ACT_funDomain_SEMIC_funDomain :
		{

			break ; 
		}
		case ACT_funDomain :
		{

			break ; 
		}
		case ACT_returnType_INT :
		{

			break ; 
		}
		case ACT_returnType_DOUBLE :
		{

			break ; 
		}
		case ACT_returnType_CHAR :
		{

			break ; 
		}
		case ACT_returnType_BOOL :
		{

			break ; 
		}
		case ACT_returnType_VOID :
		{

			break ; 
		}
		case ACT_formalParam_paramList :
		{

			break ; 
		}
		case ACT_formalParam :
		{

			break ; 
		}
		case ACT_paramList_type_ID_COMMA_paramList :
		{

			break ; 
		}
		case ACT_paramList_type_ID :
		{

			break ; 
		}
		case ACT_type_INT :
		{

			break ; 
		}
		case ACT_type_DOUBLE :
		{

			break ; 
		}
		case ACT_type_BOOL :
		{

			break ; 
		}
		case ACT_type_CHAR :
		{

			break ; 
		}
		case ACT_declaration_type_idList_SEMIC :
		{

			break ; 
		}
		case ACT_idList_ID_COMMA_idList :
		{

			break ; 
		}
		case ACT_idList_ID :
		{

			break ; 
		}
		case ACT_assignment_ID_ASSIGN_EXP_SEMIC :
		{

			break ; 
		}
		case ACT_assignment_ID_ASSIGN_funApply :
		{

			break ; 
		}
		case ACT_assignment_singleOP_SEMIC :
		{

			break ; 
		}
		case ACT_EXP_E_AND_EXP :
		{

			break ; 
		}
		case ACT_EXP_E_OR_EXP :
		{

			break ; 
		}
		case ACT_EXP_E :
		{

			break ; 
		}
		case ACT_E_T_ADD_E :
		{

			break ; 
		}
		case ACT_E_T_SUB_E :
		{

			break ; 
		}
		case ACT_E_T :
		{

			break ; 
		}
		case ACT_T_F_MUL_OR_INDIR_T :
		{

			break ; 
		}
		case ACT_T_F_DIV_T :
		{

			break ; 
		}
		case ACT_T_F :
		{

			break ; 
		}
		case ACT_F_G_relOP_G :
		{

			break ; 
		}
		case ACT_F_G :
		{

			break ; 
		}
		case ACT_G_LR_BRAC_EXP_RR_BRAC :
		{

			break ; 
		}
		case ACT_G_ID :
		{

			break ; 
		}
		case ACT_G_TRUE :
		{

			break ; 
		}
		case ACT_G_FALSE :
		{

			break ; 
		}
		case ACT_G_DIGIT :
		{

			break ; 
		}
		case ACT_G_CHAR_C :
		{

			break ; 
		}
		case ACT_DIGIT_INT_C :
		{

			break ; 
		}
		case ACT_DIGIT_REAL_C :
		{

			break ; 
		}
		case ACT_relOP_EQ :
		{

			break ; 
		}
		case ACT_relOP_NEQ :
		{

			break ; 
		}
		case ACT_relOP_GE :
		{

			break ; 
		}
		case ACT_relOP_GT :
		{

			break ; 
		}
		case ACT_relOP_LE :
		{

			break ; 
		}
		case ACT_relOP_LT :
		{

			break ; 
		}
		case ACT_funApply_ID_LR_BRAC_acturalParam_RR_BRAC_SEMIC :
		{

			break ; 
		}
		case ACT_acturalParam_idList :
		{

			break ; 
		}
		case ACT_acturalParam :
		{

			break ; 
		}
		case ACT_singleOP_INC_ID :
		{

			break ; 
		}
		case ACT_singleOP_ID_INC :
		{

			break ; 
		}
		case ACT_singleOP_DEC_ID :
		{

			break ; 
		}
		case ACT_singleOP_ID_DEC :
		{

			break ; 
		}
		case ACT_condition_IF_LR_BRAC_EXP_ACT_2_RR_BRAC_funBody :
		{

			break ; 
		}
		case ACT_condition_IF_LR_BRAC_EXP_ACT_2_RR_BRAC_funBody_ACT_3_ELSE_funBody :
		{

			break ; 
		}
		case ACT_loop_FOR_LR_BRAC_forAssignPart_ACT_4_SEMIC_forBoolPart_ACT_5_SEMIC_forAssignPart_ACT_6_RR_BRAC_funBody :
		{

			break ; 
		}
		case ACT_forAssignPart_forAssignList :
		{

			break ; 
		}
		case ACT_forAssignPart :
		{

			break ; 
		}
		case ACT_forAssignList_forAssignment_COMMA_forAssignList :
		{

			break ; 
		}
		case ACT_forAssignList_forAssignment :
		{

			break ; 
		}
		case ACT_forAssignment_ID_ASSIGN_EXP :
		{

			break ; 
		}
		case ACT_forAssignment_singleOP :
		{

			break ; 
		}
		case ACT_forBoolPart_EXP :
		{

			break ; 
		}
		case ACT_forBoolPart :
		{

			break ; 
		}
		case ACT_jumpWord_returnWord :
		{

			break ; 
		}
		case ACT_jumpWord_CONTINUE_SEMIC :
		{

			break ; 
		}
		case ACT_jumpWord_BREAK_SEMIC :
		{

			break ; 
		}
		case ACT_returnWord_RETURN_returnVal_SEMIC :
		{

			break ; 
		}
		case ACT_returnVal_EXP :
		{

			break ; 
		}
		case ACT_returnVal :
		{

			break ; 
		}
		case ACT_io_PRINTF_LR_BRAC_printContent_RR_BRAC_SEMIC :
		{

			break ; 
		}
		case ACT_io_SCANF_LR_BRAC_STRING_C_COMMA_REFERENCE_ID_RR_BRAC_SEMIC :
		{

			break ; 
		}
		case ACT_printContent_STRING_C :
		{

			break ; 
		}
		case ACT_printContent_STRING_C_COMMA_ID :
		{

			break ; 
		}
		case ACT_mainFun_INT_MAIN_ACT_1_LR_BRAC_formalParam_RR_BRAC_funBody :
		{

			break ; 
		}
		case ACT_ACT_1 :
		{

			break ; 
		}
		case ACT_ACT_2 :
		{

			break ; 
		}
		case ACT_ACT_3 :
		{

			break ; 
		}
		case ACT_ACT_4 :
		{

			break ; 
		}
		case ACT_ACT_5 :
		{

			break ; 
		}
		case ACT_ACT_6 :
		{

			break ; 
		}
		default:
			break ;
	}
}
